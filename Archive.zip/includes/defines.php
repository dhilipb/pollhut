<?php
	// URL Related
	define("HOST", $_SERVER["HTTP_HOST"]);
    define("SITEURL", "http://" . HOST); // No trailing slash
	define("LOCAL", (strpos(SITEURL, "pollhut.com") === false));
	define("PATH", $_SERVER["REQUEST_URI"]);
	define("CURRENT_URL", SITEURL . PATH);
	define("REFERER", $_SERVER["HTTP_REFERER"]);
	
    // Database related
    define("MYSQL_HOST", "localhost");
    define("MYSQL_USER", "cosmoses");
    define("MYSQL_PASS", "Infit3ch!");
    define("MYSQL_DB", "cosmoses_compareem");
    
    // Site Related
    define("SITENAME", "PollHut");
    define("JQUERY", "http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js");
	
    // General
    define("BULLET", "&#8226;");
    define("INFINITE", 9999999);
    
    // Post Related
    // Box
    define("ITEMS_PER_ROW", 2); // number of items per row (box)
    define("ROWS_TO_SHOW", 4);  // no of rows to show for a list of posts
    // Full width
    define("POLLS_PER_PAGE", 10);
   	define("BREADCRUMB", "/");
    define("TITLE_LIMIT", 40);
	
	/*
    // Social Logins
    // Facebook
    define("FACEBOOK_KEY", "197983963584990");
    define("FACEBOOK_SECRET", "2cb6b3ab394b46876b0d991953091562");
    define("FACEBOOK_LINK", SITEURL."/login/facebook");
    define("FACEBOOK_TOKEN_URL", "https://graph.facebook.com/oauth/access_token?"
           . "client_id=" . FACEBOOK_KEY
           . "&client_secret=" . FACEBOOK_SECRET 
           . "&redirect_uri=" . urlencode(FACEBOOK_LINK) 
           . "&code=");
    define("FACEBOOK_API_URL", "http://www.facebook.com/dialog/oauth/?scope=email"
           . "&client_id=" . FACEBOOK_KEY 
           . "&redirect_uri=" . urlencode(FACEBOOK_LINK));
           
    // Twitter
    define("TWITTER_KEY", "fwZAP9QXD4xneQMFTcghAA");
    define("TWITTER_SECRET", "KSFHmJO6eJKRlpN1ZVix2g8AdYiGQzWjx2f15fjpts");
    define("TWITTER_LINK", SITEURL."/login/twitter");
	define("TWITTER_TOKEN", "420671271-ZCERPuVsTZ04ONdEaw5cmvokTsPigFbZGNmDZ8WZ");
	define("TWITTER_TOKEN_SECRET", "oQVRdQuyqYjWjN3ezSufpGQCR2DTcG2fcl1DBbdJADw");
    
    // Google
    define("GOOGLE_KEY", "www.dhilip.co.uk");
    define("GOOGLE_SECRET", "-Xm4mt4UCo0fIOXqRk0GN0N2");
    define("GOOGLE_LINK", SITEURL."/login/google");
    define("GOOGLE_OAUTH_HOST", "https://www.google.com");
    define("GOOGLE_REQUEST_TOKEN_URL", GOOGLE_OAUTH_HOST . "/accounts/OAuthGetRequestToken");
    define("GOOGLE_AUTHORIZE_URL", GOOGLE_OAUTH_HOST . "/accounts/OAuthAuthorizeToken");
    define("GOOGLE_ACCESS_TOKEN_URL", GOOGLE_OAUTH_HOST . "/accounts/OAuthGetAccessToken");
    */
   
    // Points
    define("POINTS_LOGIN", 3);
    define("POINTS_POST", 40);
    define("POINTS_COMMENT", 10);
    define("POINTS_LIKE", 5);
    define("POINTS_VOTE", 5);
    
	// Meta
	define("SEO_KEYWORDS", "poll, polls, opinions, comparison, compare, votes, difference between, review");
    
    // User Related
    $AGES = array(18 => "0 - 18", 24 => "19 - 24", 30 => "25 - 30", 40 => "31 - 40", 50 => "41 - 50", 60 => "51 - 60", 100 => "60+");
	
	// URL Related
	$CUSTOM_URLS  = array("/user/logout" => "/logout",
							"/user/login" => "/login"); 
  ?>