<?php
	require_once("includes/classes/post.php");
	require_once("includes/classes/user.php");
?>