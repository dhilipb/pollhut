<div class="chart">
<?php 
	drawLikesChart($post); 
?>
</div>