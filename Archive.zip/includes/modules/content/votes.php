<div class="chart" style="width: 100%; margin: 0; border: none; padding: 0;">
    <?php 
        require_once("includes/chart/get.php");
        drawPostChart($post); 
    ?>
</div>