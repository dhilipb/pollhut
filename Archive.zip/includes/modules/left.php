<div class="modules" id="leftmodule">
    <div class="module">
        <h1>Votes</h1>
        <div class="module-content">
            <?php require("content/votes.php");?>
        </div>
    </div>
    <? /*
    <div class="module">
        <div class="module-content">
            <?php require("content/likes.php"); ?>            
        </div>
    </div> */ ?>
    <div class="module">
    	<h1>Tags</h1>
        <div class="module-content">
            <?php require("content/tags.php"); ?>            
        </div>
    </div>
    
</div>