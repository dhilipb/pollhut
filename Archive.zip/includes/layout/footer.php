<div style="height: 50px"></div>
<footer>
    <p id="copyright">
    	&copy; 2011-<?=date("Y")?> <?=SITENAME?>. 
    	Developed by <a href='//infitechsolutions.co.uk'>Infitech Solutions Ltd.</a>
    </p>
    <ul id="footer-nav">
        <li class='first'>
     		<a href="https://twitter.com/pollhut" class="twitter-follow-button" data-show-count="false">Follow @pollhut</a>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
		</li>
        <!--li><a href="<?=linkify("page","contact");?>">Contact</a></li-->
        <li class='last' style="padding-top: 6px"><a href="<?=linkify("page","privacy");?>">Privacy Policy</li></a></li>
    </ul>
</footer>