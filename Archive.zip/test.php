<style>body{background: black;}</style>
<iframe src="http://pollhut.dev/embed/12?color=0&title=true&show=all" style="width: 300px; height: 250px; background:white" frameborder="0"/>